package tcp;

import java.net.ServerSocket;
import java.io.IOException;
import java.net.Socket;
import java.io.InputStream;
import java.io.OutputStream;

public class ServidorTCP {

    public static void main(String args[]){
        
        try{
            ServerSocket ss = new ServerSocket (1234);
            System.out.println("Aguardando...");
            Socket s = ss.accept();
            
            InputStream entrada = s.getInputStream();
            OutputStream saida = s.getOutputStream();
            saida.write("Saudações, terráqueos.".toString().getBytes());
            saida.close();
            
        }catch(IOException e){
            e.printStackTrace();
        }
    }
}
