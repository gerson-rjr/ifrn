package tcp;

import java.net.*;
import java.io.*;

public class ClienteTCP {
    
    public static void main(String args[]){
        try{
            Socket s = new Socket("127.0.0.1", 1234);
            InputStream is = s.getInputStream();
            byte[] b = new byte[100];
            is.read(b);
            String str = new String(b);
            System.out.println(str);
            
        }catch(UnknownHostException uhe){
            uhe.printStackTrace();
        }catch(IOException ioe){
            ioe.printStackTrace();
        }
    }
    
}
